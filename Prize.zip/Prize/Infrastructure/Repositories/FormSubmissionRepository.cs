﻿using Core.Entities;
using Core.Interfaces;
using Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Repositories
{
    public class FormSubmissionRepository : IFormSubmissionRepository
    {
        private readonly PrizeDbContext _context;

        public FormSubmissionRepository(PrizeDbContext context)
        {
            _context = context;
        }

        public async Task<FormSubmission> AddAsync(FormSubmission formSubmission)
        {
            try 
            {
                _context.FormSubmissions.Add(formSubmission);
                await _context.SaveChangesAsync();
                return formSubmission;
            }
            catch (Exception ex)
            {
                // You can log the exception here if you have a logger
                // e.g. _logger.LogError(ex, "Error adding FormSubmission");

                // Optionally, rethrow or return null, or handle as needed
                //throw new ApplicationException("An error occurred while saving the form submission.", ex);
                throw new Exception("An error occurred while saving the form submission." + ex.Message + (ex.InnerException?.Message??""), ex);
            }
        }

        public async Task<FormSubmission> UpdateAsync(FormSubmission formSubmission)
        {
            _context.FormSubmissions.Update(formSubmission);
            await _context.SaveChangesAsync();
            return formSubmission;
        }

        public async Task<FormSubmission?> GetByFormSubmissionIdAsync(int formSubmissionId)
        {
            return await _context.FormSubmissions.Include(f => f.SubmittedAnswers).ThenInclude(sa => sa.Question)
                    .Include(f => f.SubmittedAnswers).ThenInclude(sa => sa.Option)
                    .Include(f => f.SubmittedAttachments).ThenInclude(sa => sa.Question)
                    .Include(f => f.SubmittedAttachments).ThenInclude(sa => sa.Option)
                    .Include(f => f.SubmittedAttachments).ThenInclude(sa => sa.AttachmentType)
                    .Include(f => f.SubmittedAttachments).ThenInclude(sa => sa.SubSection)
                .Where(f => f.Id.Equals(formSubmissionId))
                .FirstOrDefaultAsync();
        }
    }
}
