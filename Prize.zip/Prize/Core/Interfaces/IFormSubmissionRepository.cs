﻿using Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Interfaces
{
    public interface IFormSubmissionRepository
    {
        Task<FormSubmission> AddAsync(FormSubmission formSubmission);
        Task<FormSubmission> UpdateAsync(FormSubmission formSubmission);
        Task<FormSubmission?> GetByFormSubmissionIdAsync(int formSubmissionId);
    }
}
