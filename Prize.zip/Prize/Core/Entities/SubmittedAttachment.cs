﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Entities
{
    public class SubmittedAttachment
    {
        public int Id { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        //[ForeignKey("FormSubmission")]
        public int SubmissionId { get; set; }
        public int? SubSectionId { get; set; }
        public int? QuestionId { get; set; }
        public int? OptionId { get; set; }
        public int AttachmentTypeId { get; set; }
        public bool isActive { get; set; }
        public bool isDeleted { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime LastModifiedAt { get; set; }
        public string CreatedBy { get; set; }
        public string LastModifiedBy { get; set; }
        public virtual FormSubmission Submission { get; set; }
        public virtual FormSubSection? SubSection { get; set; }
        public virtual Question? Question { get; set; }
        public virtual Option? Option { get; set; }
        public virtual AttachmentType AttachmentType { get; set; }
    }
}
