﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Models.Common
{
    public class JWTModel
    {
        public string EncKey { get; set; }
        public string MasterKey { get; set; }

    }
}
