﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Features.Forms.Queries.GetNewForm.GetNewDepartmentForm
{
    public class GetNewDepartmentFormQueryModel
    {
        public int FormCategoryId { get; set; }
    }
}
