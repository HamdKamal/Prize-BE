﻿using Core.Entities;
using Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Features.Forms.Commands.UpdateNewForm
{
    public class UpdateFormCommandHandler : IUpdateFormCommandHandler
    {
        private IFormSubmissionRepository _formSubmissionRepository;
        private ISubmittedAnswerRepository _submittedAnswerRepository;
        private ISubmittedAttachmentRepository _submittedAttachmentRepository;
        private IParticipantRepository _participantRepository;

        public UpdateFormCommandHandler(
            IFormSubmissionRepository formSubmissionRepository,
            ISubmittedAnswerRepository submittedAnswerRepository,
            ISubmittedAttachmentRepository submittedAttachmentRepository,
            IParticipantRepository participantRepository
            ) 
        { 
            _formSubmissionRepository = formSubmissionRepository;
            _submittedAnswerRepository = submittedAnswerRepository;
            _submittedAttachmentRepository = submittedAttachmentRepository;
            _participantRepository = participantRepository;
        }

        public async Task<UpdateFormCommandResult> HandleAsync(UpdateFormCommandModel commandModel)
        {
            UpdateFormCommandResult result = new UpdateFormCommandResult();

            commandModel.submission.SubmittedAttachments = null;
            commandModel.submission.SubmittedAnswers = null;
            commandModel.submission.Participants = null;

            result.submission = await _formSubmissionRepository.UpdateAsync(commandModel.submission);
            var updatedAnswers = await _submittedAnswerRepository.UpdateRangeAsync(commandModel.answers.Where(ans => ans.Id > 0).ToList());
            var updatedAttachments = await _submittedAttachmentRepository.UpdateRangeAsync(commandModel.attachments.Where(att => att.Id > 0).ToList());
           
            var insertedAnswers = await _submittedAnswerRepository.AddRangeAsync(commandModel.answers.Where(ans => ans.Id == 0).ToList());
            var insertedAttachments = await _submittedAttachmentRepository.AddRangeAsync(commandModel.attachments.Where(att => att.Id == 0).ToList());
            
            result.answers = updatedAnswers.Concat(insertedAnswers).ToList();
            result.attachments = updatedAttachments.Concat(insertedAttachments).ToList();

            var existingParticipants = await _participantRepository.GetByFormSubmissionIdAsync(result.submission.Id);
            if (existingParticipants != null && existingParticipants.Count() > 0)
            {
                foreach (Participant participant in existingParticipants)
                {
                    participant.isDeleted = true;
                    participant.isActive = false;
                }

                var deletedParticpants = await _participantRepository.UpdateRangeAsync(existingParticipants);

            }

            if (commandModel.particpants != null && commandModel.particpants.Count() > 0)
            {                
                var insertedParticipants = await _participantRepository.AddRangeAsync(commandModel.particpants.Where(p => p.Id == 0).ToList());

                result.particpants = insertedParticipants;
            }

            return result;
        }
    }
}
