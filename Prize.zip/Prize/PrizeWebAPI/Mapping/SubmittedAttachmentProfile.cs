﻿using AutoMapper;
using PrizeWebAPI.Models;
using Core.Entities;

namespace PrizeWebAPI.Mapping
{
    public class SubmittedAttachmentProfile : Profile
    {
        public SubmittedAttachmentProfile()
        {
            CreateMap<SubmittedAttachment, SubmittedAttachmentDTO>().ReverseMap();
        }
    }
}

