using Application.Abstractions.Common;
using Application.Features.Forms.Commands.CreateNewForm;
using Application.Features.Forms.Commands.UpdateNewForm;
using Application.Features.Forms.Queries.GetNewForm.GetNewDepartmentForm;
using Application.Features.Forms.Queries.GetNewForm.GetNewIndividualForm;
using Application.Features.Forms.Queries.GetSavedForm;
using Application.Mapping;
using Application.Models.Common;
using AutoMapper;
using Core.Interfaces;
using Infrastructure.Data;
using Infrastructure.Repositories;
using Infrastructure.Services;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.EntityFrameworkCore;
using PrizeWebAPI.Extensions;
using PrizeWebAPI.Mapping;
using PrizeWebAPI.Models;

var builder = WebApplication.CreateBuilder(args);

// Manually register AutoMapper and scan profiles
var mapperConfig = new MapperConfiguration(mc =>
{
    mc.AddProfile(new CategoryProfile());
    mc.AddProfile(new DepartmentFormProfile());
    mc.AddProfile(new FormSectionProfile());
    mc.AddProfile(new FormSubmissionProfile());
    mc.AddProfile(new FormSubSectionProfile());
    mc.AddProfile(new IndividualFormProfile());
    mc.AddProfile(new OptionProfile());
    mc.AddProfile(new QuestionOptionProfile());
    mc.AddProfile(new QuestionProfile());
    mc.AddProfile(new QuestionTypeProfile());
    mc.AddProfile(new SavedFormProfile());
    mc.AddProfile(new StatusProfile());
    mc.AddProfile(new SubmittedAnswerProfile());
    mc.AddProfile(new SubmittedAttachmentProfile());
});

IMapper mapper = mapperConfig.CreateMapper();
builder.Services.AddSingleton(mapper);
builder.Services.AddAutoMapper(typeof(VEmployeeRecordAllMappingProfile).Assembly);

// Add services to the container.

builder.Services.AddControllers();

builder.Services.ConfigureAuthenticationSettings(builder.Configuration);

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//builder.Services.AddSwaggerGen(c => { c.SwaggerDoc("v2", new OpenApiInfo { Title = " API", Version = "v2" }); });

// Register DbContexts
builder.Services.AddDbContext<PrizeDbContext>(options =>
      options.UseSqlServer(
          builder.Configuration.GetConnectionString("DefaultConnection") ?? throw new InvalidOperationException("Connection string DefaultConnection not found"),
          options => options.EnableRetryOnFailure()
      )
);

builder.Services.AddDbContext<SWCCSharedDbContext>(options =>
          options.UseSqlServer(builder.Configuration.GetConnectionString("SWCCSharedDatabase"),
          sqlServerOptions => sqlServerOptions.CommandTimeout(3000)));

//builder.Services.AddScoped<SWCCSharedDbContext>(provider => provider.GetService<SWCCSharedDbContext>());


builder.Services.AddHttpContextAccessor();

//Register AuthService
builder.Services.AddTransient<IAuthService, AuthService>();
builder.Services.AddTransient<IUserService, UserService>();

//Register QueryHandlers
builder.Services.AddTransient<IGetNewDepartmentFormQueryHandler, GetNewDepartmentFormQueryHandler>();
builder.Services.AddTransient<IGetNewIndividualFormQueryHandler, GetNewIndividualFormQueryHandler>();
builder.Services.AddTransient<IGetSavedFormQueryHandler, GetSavedFormQueryHandler>();

//Register CommandHandlers
builder.Services.AddTransient<ICreateNewFormCommandHandler, CreateNewFormCommandHandler>();
builder.Services.AddTransient<IUpdateFormCommandHandler, UpdateFormCommandHandler>();

//Register Repositories
builder.Services.AddTransient<ICategoryRepository, CategoryRepository>();
builder.Services.AddTransient<IFormSectionRepository, FormSectionRepository>();
builder.Services.AddTransient<IFormSubmissionRepository, FormSubmissionRepository>();
builder.Services.AddTransient<IFormSubSectionRepository, FormSubSectionRepository>();
builder.Services.AddTransient<IParticipantRepository, ParticipantRepository>();
builder.Services.AddTransient<IQuestionRepository, QuestionRepository>();
builder.Services.AddTransient<ISubmittedAnswerRepository, SubmittedAnswerRepository>();
builder.Services.AddTransient<ISubmittedAttachmentRepository, SubmittedAttachmentRepository>();
builder.Services.AddTransient<IUserRepository, UserRepository>();

builder.Services.AddCors(options =>
    options.AddPolicy("CorsPolicy",
    builder => builder.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin().SetIsOriginAllowed((host) => true))
);

//// Allow all origins (for development only)
//builder.Services.AddCors(options =>
//{
//    options.AddPolicy("AllowLocalhost3000", policy =>
//    {
//        policy.WithOrigins("http://localhost:3000")
//              .AllowAnyHeader()
//              .AllowAnyMethod();
//    });
//});


builder.Services.Configure<AppSettings>(
    builder.Configuration.GetSection("AppSettings"));

builder.Services.Configure<JWTModel>(builder.Configuration.GetSection("JWTValidator"));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();

    //app.UseSwagger(options =>
    //{
    //    options.SerializeAsV2 = true;
    //});

    //app.UseSwaggerUI(c =>
    //{
    //    c.SwaggerEndpoint("../swagger/v2/swagger.json", "API V2");
    //});
}

app.UseHttpsRedirection();

var forwardingOptions = new ForwardedHeadersOptions() { ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto | ForwardedHeaders.All };
app.UseForwardedHeaders(forwardingOptions);

app.Use(async (context, next) =>
{
    context.Response.Headers.Append("X-Frame-Options", "DENY");
    context.Response.Headers.Append("X-XSS-Protection", "1; mode=block");
    context.Response.Headers.Append("X-Content-Type-Options", "nosniff");
    context.Response.Headers.Append("Referrer-Policy", "no-referrer");
    context.Response.Headers.Append("X-Permitted-Cross-Domain-Policies", "none");
    context.Response.Headers.Append("Content-Security-Policy", "default-src * 'unsafe-inline' 'unsafe-eval'; script-src * 'unsafe-inline' 'unsafe-eval'; connect-src * 'unsafe-inline'; img-src * data: blob: 'unsafe-inline'; frame-src *; style-src * 'unsafe-inline';");
    context.Response.Headers.Remove("X-AspNet-Version");
    context.Response.Headers.Remove("X-Powered-By");
    context.Response.Headers.Remove("Server");

    await next.Invoke();
});

app.UseCors("CorsPolicy");
//app.UseRouting();

app.UseAuthentication();

app.UseAuthorization();

app.MapControllers();

app.Run();
