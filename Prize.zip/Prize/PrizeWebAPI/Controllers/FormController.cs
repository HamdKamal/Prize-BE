﻿using Application.Abstractions.Common;
using Application.Features.Forms.Commands.CreateNewForm;
using Application.Features.Forms.Commands.UpdateNewForm;
using Application.Features.Forms.Queries.GetNewForm.GetNewDepartmentForm;
using Application.Features.Forms.Queries.GetNewForm.GetNewIndividualForm;
using Application.Features.Forms.Queries.GetSavedForm;
using Application.Models.Common;
using AutoMapper;
using Azure.Core;
using Core.Entities;
using Core.Enums;
using Core.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PrizeWebAPI.Models;


namespace PrizeWebAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    [Authorize]
    public class FormController : ControllerBase
    {
        private readonly IGetNewDepartmentFormQueryHandler _departmentFormQueryHandler;
        private readonly IGetSavedFormQueryHandler _savedFormQueryHandler;
        private readonly ICreateNewFormCommandHandler _newFormCommandHandler;
        private readonly IUpdateFormCommandHandler _updateFormCommandHandler;
        private readonly IGetNewIndividualFormQueryHandler _individualFormQueryHandler;
        private readonly IMapper _mapper;
        private readonly IAuthService _authService;
        private readonly IConfiguration _configuration;
        private readonly IUserService _userService;
        private readonly INotificationService _notification;

        public FormController
            (
                IGetNewDepartmentFormQueryHandler departmentFormQueryHandler,
                IGetSavedFormQueryHandler savedFormQueryHandler,
                ICreateNewFormCommandHandler newFormCommandHandler,
                IUpdateFormCommandHandler updateFormCommandHandler,
                IGetNewIndividualFormQueryHandler individualFormQueryHandler,
                IMapper mapper,
                IAuthService authService,
                IConfiguration configuration,
                IUserService userService,
                INotificationService notification
            )
        {
            _departmentFormQueryHandler = departmentFormQueryHandler;
            _savedFormQueryHandler = savedFormQueryHandler;
            _newFormCommandHandler = newFormCommandHandler;
            _updateFormCommandHandler = updateFormCommandHandler;
            _individualFormQueryHandler = individualFormQueryHandler;
            _mapper = mapper;
            _authService = authService;
            _configuration = configuration;
            _userService = userService;
            _notification = notification;
        }

        //done
        [HttpGet]
        public async Task<ActionResult<DepartmentFormDTO>> GetNewDepartmentForm()
        {
            try
            {
                GetNewDepartmentFormQueryModel query = new GetNewDepartmentFormQueryModel { FormCategoryId = (int)FormCategoryEnum.Department };
                GetNewDepartmentFormQueryResult queryResult = await _departmentFormQueryHandler.HandleAsync(query);
                //FormSectionDTO result = _mapper.Map<FormSectionDTO>(queryResult);
                DepartmentFormDTO result = _mapper.Map<DepartmentFormDTO>(queryResult);

                if (result == null)
                {
                    return NotFound(new ApiResponse<DepartmentFormDTO>
                    {
                        Success = false,
                        Message = $"No data was found."
                    });
                }

                return Ok(new ApiResponse<DepartmentFormDTO>
                {
                    Success = true,
                    Message = "Department Category Form retrieved successfully.",
                    Data = result
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ApiResponse<DepartmentFormDTO>
                {
                    Success = false,
                    Message = "An error occurred while retrieving Department Category Form .",
                    Error = ex.Message
                });
            }
        }


        //pending
        [HttpGet]
        public async Task<ActionResult<IndividualFormDTO>> GetNewIndividualForm()
        {
            try
            {
                GetNewIndividualFormQueryModel query = new GetNewIndividualFormQueryModel { FormCategoryId = (int)FormCategoryEnum.Individual };
                GetNewIndividualFormQueryResult queryResult = await _individualFormQueryHandler.HandleAsync(query);
                IndividualFormDTO result = _mapper.Map<IndividualFormDTO>(queryResult);

                if (result == null)
                {
                    return NotFound(new ApiResponse<IndividualFormDTO>
                    {
                        Success = false,
                        Message = $"No data was found."
                    });
                }

                return Ok(new ApiResponse<IndividualFormDTO>
                {
                    Success = true,
                    Message = "Individual Category Form retrieved successfully.",
                    Data = result
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ApiResponse<IndividualFormDTO>
                {
                    Success = false,
                    Message = "An error occurred while retrieving Individual Category Form .",
                    Error = ex.Message
                });
            }
        }

        //done
        [HttpPost]
        public async Task<ActionResult<ApiResponse<FormSubmissionDTO>>> CreateNewFormRequest([FromForm] FormSubmissionDTO formSubmissionDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    var errors = ModelState.Values.SelectMany(v => v.Errors)
                                                  .Select(e => e.ErrorMessage)
                                                  .ToList();

                    return BadRequest(new ApiResponse<object>
                    {
                        Success = false,
                        Message = "Validation failed.",
                        Error = string.Join(" | ", errors)
                    });
                }

                if (formSubmissionDto?.SubmittedAttachments?.Count > 5)
                {
                    return StatusCode(500, new ApiResponse<FormSubmissionDTO>
                    {
                        Success = false,
                        Message = "Validation failed.",
                        Error = "Can't Attach More than 5 Files !"
                    });
                }

                //get department code
                ResponseResult<SAPUserInfoModel> userDetails = await _userService.GetUserDetails(formSubmissionDto.UserId);
                formSubmissionDto.DepartmentId = userDetails?.Model?.DepartmentCode ?? null;

                if (formSubmissionDto.SubmittedAttachments != null && formSubmissionDto.SubmittedAttachments.Count() > 0)
                {
                    //save attachments
                    foreach (var attachment in formSubmissionDto.SubmittedAttachments)
                    {
                        IFormFile file = attachment.File;
                        if (file == null || file.Length == 0) continue;
                        //return BadRequest("File is empty or not provided.");

                        var folderName = _configuration["AppSettings:DistinguishedManagementCategoryAttachmentsDirectory"];
                        // Define the target directory (can be relative or absolute)
                        var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), folderName?.ToString());

                        // Create directory if it doesn't exist
                        if (!Directory.Exists(uploadsFolder))
                        {
                            Directory.CreateDirectory(uploadsFolder);
                        }

                        // Generate a safe filename (optional: add timestamp or GUID)
                        var uniqueName = $"{Guid.NewGuid()}{Path.GetExtension(file.FileName)}";
                        var filePath = Path.Combine(uploadsFolder, uniqueName);

                        // Save the file
                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            await file.CopyToAsync(stream);
                        }

                        attachment.FilePath = filePath;
                        attachment.FileName = uniqueName;

                    }
                    //save attachments end

                }
                CreateNewFormCommandModel command = new CreateNewFormCommandModel
                {
                    submission = _mapper.Map<FormSubmission>(formSubmissionDto),
                    answers = _mapper.Map<List<SubmittedAnswer>>(formSubmissionDto.SubmittedAnswers),
                    attachments = _mapper.Map<List<SubmittedAttachment>>(formSubmissionDto.SubmittedAttachments),
                    participants = _mapper.Map<List<Participant>?>(formSubmissionDto.Participants),
                };

                CreateNewFormCommandResult commandResult = await _newFormCommandHandler.HandleAsync(command);

                FormSubmissionDTO result = new FormSubmissionDTO();
                result = _mapper.Map<FormSubmissionDTO>(commandResult.submission);
                result.SubmittedAnswers = _mapper.Map<List<SubmittedAnswerDTO>>(commandResult.answers);
                result.SubmittedAttachments = _mapper.Map<List<SubmittedAttachmentDTO>>(commandResult.attachments);
                result.Participants = _mapper.Map<List<ParticipantDTO>?>(commandResult.particpants);

                if(result.IsSubmitted)
                {
                    var ReciverEmail = new List<string> { userDetails?.Model?.Email?.ToString() ?? "" } ?? [];
                    if (ReciverEmail != null)
                    {
                        await _notification.SendAsync(new NotificationMessageModel()
                        {
                            Content = { },
                            ViewName = "msg.cshtml",
                            Subject = "جائزة الهيئة للتميز",
                            To = ReciverEmail
                        });
                    }
                }

                return CreatedAtAction(nameof(CreateNewFormRequest), new { id = formSubmissionDto.Id }, new ApiResponse<FormSubmissionDTO>
                {
                    Success = true,
                    Message = "New form created successfully.",
                    Data = result
                });
            } 
            catch (Exception ex)
            {
                return StatusCode(500, new ApiResponse<FormSubmissionDTO>
                {
                    Success = false,
                    Message = "An error occurred while creating new form.",
                    Error = ex.Message
                });
            }
        }

        //done
        [HttpPut]
        public async Task<ActionResult<ApiResponse<FormSubmissionDTO>>> UpdateFormRequest([FromForm] FormSubmissionDTO formSubmissionDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    var errors = ModelState.Values.SelectMany(v => v.Errors)
                                                  .Select(e => e.ErrorMessage)
                                                  .ToList();

                    return BadRequest(new ApiResponse<object>
                    {
                        Success = false,
                        Message = "Validation failed.",
                        Error = string.Join(" | ", errors)
                    });
                }
                if(formSubmissionDto?.SubmittedAttachments?.Count > 5)
                {
                    return StatusCode(500, new ApiResponse<FormSubmissionDTO>
                    {
                        Success = false,
                        Message = "Wrong ..",
                        Error = "Can't Attach More than 5 Files !"
                    });
                }

                if (formSubmissionDto.SubmittedAttachments != null && formSubmissionDto.SubmittedAttachments.Count > 0)
                {
                    // save attachments

                    foreach (var attachment in formSubmissionDto.SubmittedAttachments)
                    {
                        IFormFile file = attachment.File;
                        if (file == null || file.Length == 0) continue;
                        //return BadRequest("File is empty or not provided.");

                        var folderName = _configuration["AppSettings:DistinguishedManagementCategoryAttachmentsDirectory"];
                        // Define the target directory (can be relative or absolute)
                        var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), folderName?.ToString());

                        // Create directory if it doesn't exist
                        if (!Directory.Exists(uploadsFolder))
                        {
                            Directory.CreateDirectory(uploadsFolder);
                        }

                        // Generate a safe filename (optional: add timestamp or GUID)
                        var uniqueName = $"{Guid.NewGuid()}{Path.GetExtension(file.FileName)}";
                        var filePath = Path.Combine(uploadsFolder, uniqueName);

                        // Save the file
                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            await file.CopyToAsync(stream);
                        }

                        attachment.FilePath = filePath;
                        attachment.FileName = uniqueName;

                    }
                    //save attachments end

                }

                UpdateFormCommandModel command = new UpdateFormCommandModel
                {
                    submission = _mapper.Map<FormSubmission>(formSubmissionDto),
                    answers = _mapper.Map<List<SubmittedAnswer>>(formSubmissionDto.SubmittedAnswers),
                    attachments = _mapper.Map<List<SubmittedAttachment>>(formSubmissionDto.SubmittedAttachments),
                    particpants = _mapper.Map<List<Participant>?>(formSubmissionDto.Participants),
                };

                UpdateFormCommandResult commandResult = await _updateFormCommandHandler.HandleAsync(command);

                FormSubmissionDTO result = new FormSubmissionDTO();
                result = _mapper.Map<FormSubmissionDTO>(commandResult.submission);
                result.SubmittedAnswers = _mapper.Map<List<SubmittedAnswerDTO>>(commandResult.answers);
                result.SubmittedAttachments = _mapper.Map<List<SubmittedAttachmentDTO>>(commandResult.attachments);
                result.Participants = _mapper.Map<List<ParticipantDTO>?>(commandResult.particpants);

                return Ok(new ApiResponse<FormSubmissionDTO>
                {
                    Success = true,
                    Message = "Form updated successfully.",
                    Data = result
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ApiResponse<FormSubmissionDTO>
                {
                    Success = false,
                    Message = "An error occurred while updating form.",
                    Error = ex.Message
                });
            }
        }

        //done
        [HttpGet]
        public async Task<ActionResult<SavedFormDTO>> GetSavedForm([FromQuery] int submissionId)
        {
            try
            {
                GetSavedFormQueryModel query = new GetSavedFormQueryModel { FormSubmissionId = submissionId };
                GetSavedFormQueryResult queryResult = await _savedFormQueryHandler.HandleAsync(query);
                //FormSubmissionDTO result = _mapper.Map<FormSubmissionDTO>(queryResult);
                SavedFormDTO result = _mapper.Map<SavedFormDTO>(queryResult);

                if (result == null)
                {
                    return NotFound(new ApiResponse<SavedFormDTO>
                    {
                        Success = false,
                        Message = $"No data was found."
                    });
                }

                return Ok(new ApiResponse<SavedFormDTO>
                {
                    Success = true,
                    Message = "Saved Form retrieved successfully.",
                    Data = result
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ApiResponse<SavedFormDTO>
                {
                    Success = false,
                    Message = "An error occurred while retrieving Saved Form .",
                    Error = ex.Message
                });
            }
        }


    }
}
